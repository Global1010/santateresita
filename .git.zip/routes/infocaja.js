const { Router } = require('express');
const { check } = require('express-validator');
const { InfoCobro } = require('../constrollers/InfoCobro');
const { validarJWT } = require('../middlewares/validarjwt');
const { tieneRol } = require('../middlewares');
const { validarDatosIn } = require('../middlewares/validarCampos');


const router = Router();

router.get('/', [
    validarJWT,
    tieneRol('ADMIN_ROL','VENTAS_ROL'),
    check('usu_fecha', 'La Fecha es Obligatorio').not().isEmpty(),
    validarDatosIn
],InfoCobro);


module.exports = router;